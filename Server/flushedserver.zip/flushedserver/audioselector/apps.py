from django.apps import AppConfig


class AudioselectorConfig(AppConfig):
    name = 'audioselector'
